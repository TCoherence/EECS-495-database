public class DB_SETTING {
    public String DRIVER="com.mysql.cj.jdbc.Driver";
    //这里我的数据库是qcl
    public String URL="jdbc:mysql://localhost:3306/project3-nudb?serverTimezone=UTC";
    public String USER="root";
    public String PASSWORD="wang960415";
}
